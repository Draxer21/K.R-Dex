package com.draxer.dexrider.item;

import com.draxer.dexrider.DexRider;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.LodestoneTracker;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;

import java.util.Optional;

/**
 * Rastreador de la Senal: un receptor que los investigadores de Gunma dejaron sintonizado. Clic derecho busca la
 * base del Arquitecto mas cercana; la aguja la senala (como una brujula) y te dice a que distancia esta.
 */
public class SignalTrackerItem extends Item {
    public static final TagKey<Structure> TARGET = TagKey.create(Registries.STRUCTURE, DexRider.id("signal_base"));
    /** La brujula de los Kagami apunta a la casa de la montania. */
    public static final TagKey<Structure> MOUNTAIN_HOUSE = TagKey.create(Registries.STRUCTURE, DexRider.id("mountain_house"));

    private final TagKey<Structure> target;
    private final String messages;

    public SignalTrackerItem(Properties props) {
        this(props, TARGET, "tracker");
    }

    /** Busca la estructura mas cercana de {@code target}; los mensajes son message.dexrider.{messages}_static/_here/_found. */
    public SignalTrackerItem(Properties props, TagKey<Structure> target, String messages) {
        super(props);
        this.target = target;
        this.messages = messages;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel server) || !(player instanceof net.minecraft.server.level.ServerPlayer sp)) return InteractionResult.SUCCESS;
        player.getCooldowns().addCooldown(stack, 60);
        if (server.dimension() != Level.OVERWORLD) {
            sp.sendSystemMessage(Component.translatable("message.dexrider." + messages + "_static").withStyle(ChatFormatting.GRAY), true);
            return InteractionResult.SUCCESS;
        }
        BlockPos found = server.findNearestMapStructure(target, player.blockPosition(), 100, false);
        if (found == null) {
            sp.sendSystemMessage(Component.translatable("message.dexrider." + messages + "_static").withStyle(ChatFormatting.GRAY), true);
            return InteractionResult.SUCCESS;
        }
        stack.set(DataComponents.LODESTONE_TRACKER, new LodestoneTracker(Optional.of(GlobalPos.of(server.dimension(), found)), false));
        int dx = found.getX() - player.getBlockX(), dz = found.getZ() - player.getBlockZ();
        int dist = (int) Math.sqrt((double) dx * dx + (double) dz * dz);
        String dir = Math.abs(dx) > Math.abs(dz) * 2 ? (dx > 0 ? "east" : "west")
                : Math.abs(dz) > Math.abs(dx) * 2 ? (dz > 0 ? "south" : "north")
                : (dz > 0 ? "south" : "north") + (dx > 0 ? "east" : "west");
        sp.sendSystemMessage(dist < 40
                ? Component.translatable("message.dexrider." + messages + "_here").withStyle(ChatFormatting.RED)
                : Component.translatable("message.dexrider." + messages + "_found", dist, Component.translatable("direction.dexrider." + dir))
                        .withStyle(ChatFormatting.DARK_RED), true);
        server.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 0.6F);
        return InteractionResult.SUCCESS;
    }
}

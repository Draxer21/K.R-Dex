package com.draxer.dexrider.registry;

import com.draxer.dexrider.DexRider;
import com.draxer.dexrider.item.AllyBook;
import com.draxer.dexrider.item.DriverDeck;
import com.draxer.dexrider.item.SuitConfig;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

/** Datos que se guardan dentro de los ItemStack del mod. */
public final class DexComponents {
    private DexComponents() {}

    public static final DeferredRegister.DataComponents COMPONENTS =
            DeferredRegister.createDataComponents(Registries.DATA_COMPONENT_TYPE, DexRider.MODID);

    /** Carta Kamen Ride cargada en el Driver (por ahora solo "kamen_ride_dex"). */
    public static final Supplier<DataComponentType<String>> LOADED_CARD =
            COMPONENTS.registerComponentType("loaded_card", builder -> builder
                    .persistent(Codec.STRING)
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8));

    /** Mazo del Driver: cartas generadas + muestras de escaneo a medias. */
    /** Cartas guardadas en el Ride Booker (vive en el Driver). */
    public static final Supplier<DataComponentType<com.draxer.dexrider.item.BookerContents>> BOOKER =
            COMPONENTS.registerComponentType("ride_booker", builder -> builder
                    .persistent(com.draxer.dexrider.item.BookerContents.CODEC)
                    .networkSynchronized(com.draxer.dexrider.item.BookerContents.STREAM_CODEC));

    /** El Booker ya usa mazos de 27 (migrado desde los de 18). */
    /** El Booker ya se ordeno en mazos por tipo de carta (0.51). */
    public static final Supplier<DataComponentType<Boolean>> BOOKER_TYPED =
            COMPONENTS.registerComponentType("booker_typed", builder -> builder
                    .persistent(com.mojang.serialization.Codec.BOOL)
                    .networkSynchronized(net.minecraft.network.codec.ByteBufCodecs.BOOL));
    public static final Supplier<DataComponentType<Boolean>> BOOKER_V27 =
            COMPONENTS.registerComponentType("booker_v27", builder -> builder
                    .persistent(com.mojang.serialization.Codec.BOOL)
                    .networkSynchronized(net.minecraft.network.codec.ByteBufCodecs.BOOL));

    /** Carta elegida en el Ride Booker para usarla rapido (mazo * 27 + ranura). */
    public static final Supplier<DataComponentType<Integer>> BOOKER_SEL =
            COMPONENTS.registerComponentType("ride_booker_sel", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));

    /** Emotion activa de Dex: "violent" o "heroic" (en el peto, para que todos vean el traje). */
    public static final Supplier<DataComponentType<String>> EMOTION =
            COMPONENTS.registerComponentType("emotion", builder -> builder
                    .persistent(Codec.STRING)
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8));

    /** Modo de Cipher activo: "accel" o "blaster" (en el peto, para que todos vean el modelo). */
    public static final Supplier<DataComponentType<String>> CIPHER_MODE =
            COMPONENTS.registerComponentType("cipher_mode", builder -> builder
                    .persistent(Codec.STRING)
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8));

    public static final Supplier<DataComponentType<DriverDeck>> DECK =
            COMPONENTS.registerComponentType("deck", builder -> builder
                    .persistent(DriverDeck.CODEC)
                    .networkSynchronized(DriverDeck.STREAM_CODEC));

    /** Form Ride activa, guardada en el peto de Dex ("speed", "gas"...). Sin componente = Dex Form base. */
    public static final Supplier<DataComponentType<String>> FORM =
            COMPONENTS.registerComponentType("form", builder -> builder
                    .persistent(Codec.STRING)
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8));

    /** Personalizacion del traje (en el Driver, y copiada al peto mientras estas transformado). */
    public static final Supplier<DataComponentType<SuitConfig>> SUIT =
            COMPONENTS.registerComponentType("suit", builder -> builder
                    .persistent(SuitConfig.CODEC)
                    .networkSynchronized(SuitConfig.STREAM_CODEC));

    /** Selector rapido (rueda del raton mantenida): las cartas elegidas, por id de item (hasta 8), en el Driver. */
    public static final Supplier<DataComponentType<java.util.List<String>>> QUICK_PICKS =
            COMPONENTS.registerComponentType("quick_picks", builder -> builder
                    .persistent(Codec.STRING.listOf())
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list(8))));

    /** Editor del traje (0.33): las 5 ranuras de disenos, en el Driver. */
    public static final Supplier<DataComponentType<com.draxer.dexrider.item.SuitSlots>> SUIT_SLOTS =
            COMPONENTS.registerComponentType("suit_slots", builder -> builder
                    .persistent(com.draxer.dexrider.item.SuitSlots.CODEC)
                    .networkSynchronized(com.draxer.dexrider.item.SuitSlots.STREAM_CODEC));
    /** El diseno puesto, copiado al peto mientras estas transformado (lo leen todos para dibujar el traje). */
    public static final Supplier<DataComponentType<com.draxer.dexrider.item.SuitProfile>> SUIT_PROFILE =
            COMPONENTS.registerComponentType("suit_profile", builder -> builder
                    .persistent(com.draxer.dexrider.item.SuitProfile.CODEC)
                    .networkSynchronized(com.draxer.dexrider.item.SuitProfile.STREAM_CODEC));

    /** Identidad de Rider activa, guardada en el peto ("nine", "cipher", "complete"...). Sin componente = Dex. */
    public static final Supplier<DataComponentType<String>> RIDER =
            COMPONENTS.registerComponentType("rider", builder -> builder
                    .persistent(Codec.STRING)
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8));

    /** Carta de Complete Form insertada en el K-Touch: 0 = la primera, 1 = la segunda (con Kaixa). En el Driver. */
    public static final Supplier<DataComponentType<Integer>> KTOUCH_RING =
            COMPONENTS.registerComponentType("ktouch_ring", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));

    /** Ya se forjo la segunda carta de Complete Form. */
    public static final Supplier<DataComponentType<Boolean>> KTOUCH_CARD2 =
            COMPONENTS.registerComponentType("ktouch_card2", builder -> builder
                    .persistent(Codec.BOOL)
                    .networkSynchronized(ByteBufCodecs.BOOL));

    /** Emotion que el Driver ya sintio (1 = Violent, 2 = Heroic). Con las dos nace la Upgrade Form. */
    public static final Supplier<DataComponentType<Integer>> EMOTIONS_SEEN =
            COMPONENTS.registerComponentType("emotions_seen", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));

    /** La carta de Complete Form ya subio a Nv.2 (en el Driver). */
    /** Nivel de la Form Ride activa (en el peto, para que el cliente lo vea: tamano de las alas de Sky). */
    public static final Supplier<DataComponentType<Integer>> FORM_LEVEL =
            COMPONENTS.registerComponentType("form_level", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));
    public static final Supplier<DataComponentType<Integer>> COMPLETE_LEVEL =
            COMPONENTS.registerComponentType("complete_level", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));

    /** Complete Form Nv.2 activa (en el peto, para el modelo). */
    public static final Supplier<DataComponentType<Boolean>> COMPLETE_LV2 =
            COMPONENTS.registerComponentType("complete_lv2", builder -> builder
                    .persistent(Codec.BOOL)
                    .networkSynchronized(ByteBufCodecs.BOOL));

    /** Driver prestado: uuid del duenio y su nombre (el Driver los lleva mientras esta prestado). */
    public static final Supplier<DataComponentType<String>> LENT_BY =
            COMPONENTS.registerComponentType("lent_by", builder -> builder.persistent(Codec.STRING).networkSynchronized(ByteBufCodecs.STRING_UTF8));
    public static final Supplier<DataComponentType<String>> LENT_OWNER =
            COMPONENTS.registerComponentType("lent_owner", builder -> builder.persistent(Codec.STRING).networkSynchronized(ByteBufCodecs.STRING_UTF8));
    /** Forma del ultimo portador del Driver (para la carta Kamen Ride: Portador). */
    public static final Supplier<DataComponentType<SuitConfig>> BEARER_SUIT =
            COMPONENTS.registerComponentType("bearer_suit", builder -> builder.persistent(SuitConfig.CODEC).networkSynchronized(SuitConfig.STREAM_CODEC));
    public static final Supplier<DataComponentType<String>> BEARER_NAME =
            COMPONENTS.registerComponentType("bearer_name", builder -> builder.persistent(Codec.STRING).networkSynchronized(ByteBufCodecs.STRING_UTF8));

    /** Upgrade Form activa (en el peto, para que todos vean el traje). */
    public static final Supplier<DataComponentType<Boolean>> UPGRADE =
            COMPONENTS.registerComponentType("upgrade", builder -> builder
                    .persistent(Codec.BOOL)
                    .networkSynchronized(ByteBufCodecs.BOOL));

    /** Escaneo en curso (en el peto, para que todos lo vean): tick de juego en que termina; negativo = recien completado. */
    public static final Supplier<DataComponentType<Long>> SCAN_FX =
            COMPONENTS.registerComponentType("scan_fx", builder -> builder
                    .persistent(Codec.LONG)
                    .networkSynchronized(ByteBufCodecs.VAR_LONG));

    /** El Driver ya forjo el K-Touch (para no darlo dos veces). */
    public static final Supplier<DataComponentType<Boolean>> KTOUCH_FORGED =
            COMPONENTS.registerComponentType("ktouch_forged", builder -> builder
                    .persistent(Codec.BOOL)
                    .networkSynchronized(ByteBufCodecs.BOOL));

    /** Amigos Rider: version, descanso, invocacion activa y casa de cada uno (en el Driver). */
    /** Lo que los amigos Rider aprendieron mirandote trabajar (solo servidor). */
    /** Encargos de los amigos de U.A. (rider -> [encargo, progreso, aceptado, avisado]). */
    public static final Supplier<DataComponentType<java.util.Map<String, java.util.List<Integer>>>> UA_MISSIONS =
            COMPONENTS.registerComponentType("ua_missions", builder -> builder
                    .persistent(Codec.unboundedMap(Codec.STRING, Codec.INT.listOf())));

    /** Diario de Yusuke (0.55): entradas "dia|clave|arg|arg" (los args con # se traducen). */
    public static final Supplier<DataComponentType<java.util.List<String>>> DIARY =
            COMPONENTS.registerComponentType("diary", builder -> builder
                    .persistent(Codec.STRING.listOf())
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list())));

    public static final Supplier<DataComponentType<com.draxer.dexrider.item.AllySkills>> ALLY_SKILLS =
            COMPONENTS.registerComponentType("ally_skills", builder -> builder
                    .persistent(com.draxer.dexrider.item.AllySkills.CODEC));

    public static final Supplier<DataComponentType<AllyBook>> ALLIES =
            COMPONENTS.registerComponentType("allies", builder -> builder
                    .persistent(AllyBook.CODEC)
                    .networkSynchronized(AllyBook.STREAM_CODEC));

    /** Modulo cargado en el Module Driver (0 taladro, 1 gancho, 2 soplete). */
    public static final Supplier<DataComponentType<Integer>> MODULE =
            COMPONENTS.registerComponentType("module", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));

    /** Modo del Ride Booker: false = espada, true = pistola. */
    public static final Supplier<DataComponentType<Boolean>> GUN_MODE =
            COMPONENTS.registerComponentType("gun_mode", builder -> builder
                    .persistent(Codec.BOOL)
                    .networkSynchronized(ByteBufCodecs.BOOL));

    /** Ride Booker: tiempo de juego del ultimo cambio espada/pistola (el cliente anima la transformacion con el). */
    public static final Supplier<DataComponentType<Long>> BOOKER_SHIFT =
            COMPONENTS.registerComponentType("booker_shift", builder -> builder
                    .networkSynchronized(ByteBufCodecs.VAR_LONG));
}
